---

excalidraw-plugin: parsed

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
LibOS ^JhOF0CVA

APP ^T3YV7HMy

CPU  MEM  IO ^lzj6pEgD

Image ^U9Z6sPIA

SBI-request ^DFd9BZME

RustSBI ^kRQf2u7U

APP ^HMaHuPKN

Qemu加载
app+os Image ^Q1vbeJnD

函数调用 ^ReUkMTQm

S-Mode ^XcoycXep

M-Mode ^HnfjQIyK

OS ^Xdln7jVm

SBI-service ^T1eJDVYa

建立栈空间 ^F7qjg9kk

bss段清零 ^QVp5tson

APP运行前的
初始化工作 ^C9Xp75L4

输出字符串 ^0koKzjAw

关机shutdown ^D2cvnKGq

OS Service ^TtcTgT0o

panic处理 ^C1egQfdG

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://excalidraw.com",
	"elements": [
		{
			"type": "rectangle",
			"version": 405,
			"versionNonce": 558481645,
			"isDeleted": false,
			"id": "hBQ08A4upujqUtPD5FEHl",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -151.5,
			"y": -227.16667938232422,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 324,
			"height": 316.16666412353516,
			"seed": 982721068,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1672198191072,
			"link": null
		},
		{
			"type": "line",
			"version": 575,
			"versionNonce": 1105252451,
			"isDeleted": false,
			"id": "OEvB2teYr82JejWf3kiwx",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "dashed",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -142.593994140625,
			"y": -160.64083862304688,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 319.6375474132318,
			"height": 0.8502960905432673,
			"seed": 1094290068,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1672198191072,
			"link": null,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					319.6375474132318,
					0.8502960905432673
				]
			]
		},
		{
			"type": "text",
			"version": 210,
			"versionNonce": 1704794957,
			"isDeleted": false,
			"id": "JhOF0CVA",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 179.5833740234375,
			"y": -44.33331298828125,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 53,
			"height": 25,
			"seed": 1076007084,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1672198191072,
			"link": null,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "LibOS",
			"rawText": "LibOS",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "LibOS"
		},
		{
			"type": "text",
			"version": 227,
			"versionNonce": 583977987,
			"isDeleted": false,
			"id": "T3YV7HMy",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -249.48431396484375,
			"y": -81.11553955078125,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 39,
			"height": 25,
			"seed": 635673108,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "r0k0gTOeJLZyt9D4Fa83q",
					"type": "arrow"
				}
			],
			"updated": 1672198191072,
			"link": null,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "APP",
			"rawText": "APP",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "APP"
		},
		{
			"type": "freedraw",
			"version": 128,
			"versionNonce": 1331046829,
			"isDeleted": false,
			"id": "jNOKLPtIfg0oPMdhAqBzI",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -255.67318915614396,
			"y": -88.79819838454995,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 6.5,
			"height": 77.25,
			"seed": 455922324,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1672198191072,
			"link": null,
			"points": [
				[
					0,
					0
				],
				[
					-0.25,
					0
				],
				[
					0,
					0
				],
				[
					0,
					0.25
				],
				[
					0.5,
					1.25
				],
				[
					0.75,
					4.5
				],
				[
					0.75,
					7.75
				],
				[
					0.75,
					15.5
				],
				[
					0.75,
					22.75
				],
				[
					1.25,
					30.75
				],
				[
					2,
					39.5
				],
				[
					2.75,
					48.5
				],
				[
					4,
					60.75
				],
				[
					5,
					67.25
				],
				[
					5.5,
					72.25
				],
				[
					6,
					75.5
				],
				[
					6,
					76.5
				],
				[
					6.25,
					77.25
				],
				[
					6.25,
					77.25
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.2802734375,
				0.310546875,
				0.310546875,
				0.412109375,
				0.4189453125,
				0.4208984375,
				0.427734375,
				0.4765625,
				0.51953125,
				0.5546875,
				0.578125,
				0.5869140625,
				0.6044921875,
				0.626953125,
				0.6435546875,
				0.646484375,
				0.6396484375,
				0.3759765625,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 142,
			"versionNonce": 398218147,
			"isDeleted": false,
			"id": "bmyZifnmg73U-Aeq525mn",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -255.17318915614396,
			"y": -89.29819838454995,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 62,
			"height": 74.25,
			"seed": 337275284,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1672198191072,
			"link": null,
			"points": [
				[
					0,
					0
				],
				[
					-0.5,
					-0.25
				],
				[
					-0.25,
					-0.25
				],
				[
					0.75,
					0
				],
				[
					6,
					0.75
				],
				[
					12.25,
					1
				],
				[
					22.75,
					0.25
				],
				[
					30,
					-0.25
				],
				[
					38,
					0
				],
				[
					45.25,
					0.25
				],
				[
					48.5,
					0.5
				],
				[
					53.25,
					1
				],
				[
					58,
					1.75
				],
				[
					59,
					2.25
				],
				[
					59.75,
					3
				],
				[
					59.5,
					6.25
				],
				[
					59.25,
					10.25
				],
				[
					59.5,
					15.5
				],
				[
					59.5,
					22.25
				],
				[
					59.75,
					32.75
				],
				[
					60,
					43.5
				],
				[
					60.5,
					51.5
				],
				[
					60.75,
					58.25
				],
				[
					61,
					63.75
				],
				[
					61.25,
					71
				],
				[
					61.25,
					72.5
				],
				[
					61,
					74
				],
				[
					61,
					74
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.294921875,
				0.326171875,
				0.4365234375,
				0.517578125,
				0.5478515625,
				0.55078125,
				0.544921875,
				0.544921875,
				0.5546875,
				0.564453125,
				0.55859375,
				0.51171875,
				0.4384765625,
				0.4365234375,
				0.4384765625,
				0.4384765625,
				0.4404296875,
				0.4423828125,
				0.4423828125,
				0.45703125,
				0.4970703125,
				0.53515625,
				0.568359375,
				0.6103515625,
				0.6591796875,
				0.6591796875,
				0.2724609375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 119,
			"versionNonce": 262040589,
			"isDeleted": false,
			"id": "feElC_jGUzJMDxymOUp1v",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -249.42318915614396,
			"y": -54.29819838454995,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 39,
			"height": 1.25,
			"seed": 1029508268,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1672198191072,
			"link": null,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-0.25
				],
				[
					1.75,
					-0.25
				],
				[
					9.75,
					0.5
				],
				[
					15.75,
					1
				],
				[
					22,
					1
				],
				[
					31.5,
					0.5
				],
				[
					37.75,
					0.75
				],
				[
					39,
					1
				],
				[
					39,
					1
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.294921875,
				0.3212890625,
				0.4873046875,
				0.51171875,
				0.51171875,
				0.529296875,
				0.615234375,
				0.64453125,
				0.63671875,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 120,
			"versionNonce": 282584899,
			"isDeleted": false,
			"id": "W8bkkBAdD1qoAXKpBp8Ws",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -249.17318915614396,
			"y": -35.54819838454995,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 47.25,
			"height": 4,
			"seed": 1923307412,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1672198191072,
			"link": null,
			"points": [
				[
					0,
					0
				],
				[
					1.5,
					-0.75
				],
				[
					2.25,
					-1
				],
				[
					8.5,
					-2.25
				],
				[
					16.5,
					-3.5
				],
				[
					23.75,
					-4
				],
				[
					34,
					-3.75
				],
				[
					40.25,
					-3
				],
				[
					45,
					-2.25
				],
				[
					47.25,
					-1.75
				],
				[
					47.25,
					-1.75
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.294921875,
				0.326171875,
				0.34765625,
				0.4365234375,
				0.4755859375,
				0.48828125,
				0.5673828125,
				0.626953125,
				0.654296875,
				0.6552734375,
				0
			]
		},
		{
			"type": "freedraw",
			"version": 119,
			"versionNonce": 1987011181,
			"isDeleted": false,
			"id": "-TcTgWruTeT1TLxxdXgrG",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -241.17318915614396,
			"y": -16.04819838454995,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 37.5,
			"height": 2.25,
			"seed": 577345684,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1672198191072,
			"link": null,
			"points": [
				[
					0,
					0
				],
				[
					-0.25,
					0.5
				],
				[
					2.75,
					1.5
				],
				[
					8,
					1.25
				],
				[
					16.5,
					0.75
				],
				[
					21.5,
					0.75
				],
				[
					26,
					1
				],
				[
					32,
					1.5
				],
				[
					37.25,
					2.25
				],
				[
					37.25,
					2.25
				]
			],
			"lastCommittedPoint": null,
			"simulatePressure": false,
			"pressures": [
				0.51953125,
				0.576171875,
				0.6083984375,
				0.6279296875,
				0.640625,
				0.6533203125,
				0.6611328125,
				0.6669921875,
				0.6669921875,
				0
			]
		},
		{
			"type": "text",
			"version": 287,
			"versionNonce": 1954547427,
			"isDeleted": false,
			"id": "lzj6pEgD",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -58.68887519130021,
			"y": 90.99198357139687,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 181,
			"height": 35,
			"seed": 2052026796,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1672198191072,
			"link": null,
			"fontSize": 32.27272727272724,
			"fontFamily": 4,
			"text": "CPU  MEM  IO",
			"rawText": "CPU  MEM  IO",
			"baseline": 29,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "CPU  MEM  IO"
		},
		{
			"type": "text",
			"version": 314,
			"versionNonce": 412257485,
			"isDeleted": false,
			"id": "U9Z6sPIA",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -252.20378207807198,
			"y": -2.452879826850392,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 58,
			"height": 25,
			"seed": 1738122121,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1672198191072,
			"link": null,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "Image",
			"rawText": "Image",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Image"
		},
		{
			"type": "rectangle",
			"version": 1040,
			"versionNonce": 1497576067,
			"isDeleted": false,
			"id": "pSA68Pi_k_sYTT3LmW--0",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "dashed",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 3.1487264668498938,
			"y": -132.32520953876445,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 158.0108642578125,
			"height": 165.13882446289062,
			"seed": 654351623,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "r0k0gTOeJLZyt9D4Fa83q",
					"type": "arrow"
				},
				{
					"id": "y2fd8UdP3H8qTFaO9e9z2",
					"type": "arrow"
				}
			],
			"updated": 1672198191072,
			"link": null
		},
		{
			"type": "rectangle",
			"version": 636,
			"versionNonce": 899771181,
			"isDeleted": false,
			"id": "b62llAAETpLKR78-J2E5i",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 10.197249416068644,
			"y": -3.208403508491017,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 151,
			"height": 35,
			"seed": 1521541385,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "DFd9BZME",
					"type": "text"
				},
				{
					"id": "r0k0gTOeJLZyt9D4Fa83q",
					"type": "arrow"
				},
				{
					"id": "DFd9BZME",
					"type": "text"
				},
				{
					"id": "DFd9BZME",
					"type": "text"
				},
				{
					"type": "text",
					"id": "DFd9BZME"
				}
			],
			"updated": 1672198191072,
			"link": null
		},
		{
			"type": "text",
			"version": 599,
			"versionNonce": 363013027,
			"isDeleted": false,
			"id": "DFd9BZME",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 15.197249416068644,
			"y": 1.791596491508983,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 141,
			"height": 25,
			"seed": 235950087,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1672198218157,
			"link": null,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "SBI-request",
			"rawText": "SBI-request",
			"baseline": 17,
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "b62llAAETpLKR78-J2E5i",
			"originalText": "SBI-request"
		},
		{
			"type": "line",
			"version": 429,
			"versionNonce": 1577418125,
			"isDeleted": false,
			"id": "4SFY276gKK-1F4Me6TLpR",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -147.7194375956501,
			"y": 47.66265972393085,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 415.6823591094464,
			"height": 1.1633085044580724,
			"seed": 701300839,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1672198191072,
			"link": null,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					415.6823591094464,
					-1.1633085044580724
				]
			]
		},
		{
			"type": "text",
			"version": 285,
			"versionNonce": 222604739,
			"isDeleted": false,
			"id": "kRQf2u7U",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 179.19724941606864,
			"y": 70.41262920635273,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 85,
			"height": 25,
			"seed": 118585737,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1672198191072,
			"link": null,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "RustSBI",
			"rawText": "RustSBI",
			"baseline": 18,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "RustSBI"
		},
		{
			"type": "rectangle",
			"version": 101,
			"versionNonce": 1492665325,
			"isDeleted": false,
			"id": "noGGWfsN-YXVdQ8tLD4DS",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -21.969437595650106,
			"y": -217.42067615253399,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 83,
			"height": 35,
			"seed": 1021931527,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"type": "text",
					"id": "zlNVVxshg9CXTqizuLIJT"
				},
				{
					"id": "_VuH6aXK5hJLj2ynza-9M",
					"type": "arrow"
				},
				{
					"id": "MLQukHBehXYC13cDZX2sq",
					"type": "arrow"
				}
			],
			"updated": 1672198191072,
			"link": null
		},
		{
			"type": "text",
			"version": 47,
			"versionNonce": 76545379,
			"isDeleted": false,
			"id": "HMaHuPKN",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -16.969437595650106,
			"y": -212.42067615253399,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 73,
			"height": 25,
			"seed": 1203540999,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1672198191072,
			"link": null,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "APP",
			"rawText": "APP",
			"baseline": 18,
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "noGGWfsN-YXVdQ8tLD4DS",
			"originalText": "APP"
		},
		{
			"type": "text",
			"version": 497,
			"versionNonce": 1250115149,
			"isDeleted": false,
			"id": "Q1vbeJnD",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -277.58995151166573,
			"y": -155.6988636888474,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 117,
			"height": 44,
			"seed": 1786755367,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1672198191072,
			"link": null,
			"fontSize": 20.679272465778364,
			"fontFamily": 4,
			"text": "Qemu加载\napp+os Image",
			"rawText": "Qemu加载\napp+os Image",
			"baseline": 40,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Qemu加载\napp+os Image"
		},
		{
			"type": "arrow",
			"version": 1168,
			"versionNonce": 17848579,
			"isDeleted": false,
			"id": "y2fd8UdP3H8qTFaO9e9z2",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 45.49309559067895,
			"y": -169.56864367034325,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 23.845983871996594,
			"height": 25.889449016871424,
			"seed": 397678119,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1672198191072,
			"link": null,
			"startBinding": {
				"elementId": "ReUkMTQm",
				"focus": 0.45699638274650217,
				"gap": 3.5592086906868303
			},
			"endBinding": {
				"elementId": "pSA68Pi_k_sYTT3LmW--0",
				"focus": 0.4752743628558346,
				"gap": 11.35398511470737
			},
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					23.845983871996594,
					25.889449016871424
				]
			]
		},
		{
			"type": "text",
			"version": 279,
			"versionNonce": 427814061,
			"isDeleted": false,
			"id": "ReUkMTQm",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 14.993086818412394,
			"y": -195.12785236103008,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 80,
			"height": 22,
			"seed": 120757415,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "y2fd8UdP3H8qTFaO9e9z2",
					"type": "arrow"
				}
			],
			"updated": 1672198191072,
			"link": null,
			"fontSize": 20,
			"fontFamily": 4,
			"text": "函数调用",
			"rawText": "函数调用",
			"baseline": 19,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "函数调用"
		},
		{
			"type": "line",
			"version": 71,
			"versionNonce": 809779363,
			"isDeleted": false,
			"id": "SkUn7dmHkfjxFoYVbklk8",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 170.0305624043499,
			"y": -228.42066852313945,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 88.3333740234375,
			"height": 0.6666641235351562,
			"seed": 58051913,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1672198191072,
			"link": null,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					88.3333740234375,
					0.6666641235351562
				]
			]
		},
		{
			"type": "text",
			"version": 174,
			"versionNonce": 362270477,
			"isDeleted": false,
			"id": "XcoycXep",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 184.3961629902874,
			"y": -219.36074725849102,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 57,
			"height": 22,
			"seed": 1521367657,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1672198191072,
			"link": null,
			"fontSize": 20,
			"fontFamily": 4,
			"text": "S-Mode",
			"rawText": "S-Mode",
			"baseline": 19,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "S-Mode"
		},
		{
			"type": "text",
			"version": 118,
			"versionNonce": 198849603,
			"isDeleted": false,
			"id": "HnfjQIyK",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 194.69724941606864,
			"y": 48.41265972393086,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 57,
			"height": 22,
			"seed": 87660553,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1672198191072,
			"link": null,
			"fontSize": 20,
			"fontFamily": 4,
			"text": "M-Mode",
			"rawText": "M-Mode",
			"baseline": 19,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "M-Mode"
		},
		{
			"type": "text",
			"version": 162,
			"versionNonce": 1564763501,
			"isDeleted": false,
			"id": "Xdln7jVm",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -236.53709506635323,
			"y": -36.95284930927227,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 20,
			"height": 22,
			"seed": 6407785,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1672198191072,
			"link": null,
			"fontSize": 20,
			"fontFamily": 4,
			"text": "OS",
			"rawText": "OS",
			"baseline": 19,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "OS"
		},
		{
			"type": "line",
			"version": 250,
			"versionNonce": 1404089315,
			"isDeleted": false,
			"id": "iaBnZ4e-OoDXbdg8vRq8F",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "dashed",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -214.01282248888856,
			"y": -86.15543182802867,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 189.6052135065197,
			"height": 114.59857257157563,
			"seed": 468740039,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1672198191072,
			"link": null,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					189.6052135065197,
					-114.59857257157563
				]
			]
		},
		{
			"type": "rectangle",
			"version": 845,
			"versionNonce": 63909837,
			"isDeleted": false,
			"id": "YKehM6A1Q8Tffb9RX0r-H",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 45.86396694536552,
			"y": 54.07934673564961,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 100.99993896484375,
			"height": 30,
			"seed": 1799396807,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "T1eJDVYa",
					"type": "text"
				},
				{
					"id": "r0k0gTOeJLZyt9D4Fa83q",
					"type": "arrow"
				},
				{
					"id": "T1eJDVYa",
					"type": "text"
				},
				{
					"id": "T1eJDVYa",
					"type": "text"
				},
				{
					"id": "T1eJDVYa",
					"type": "text"
				},
				{
					"type": "text",
					"id": "T1eJDVYa"
				}
			],
			"updated": 1672198191072,
			"link": null
		},
		{
			"type": "text",
			"version": 749,
			"versionNonce": 1682742285,
			"isDeleted": false,
			"id": "T1eJDVYa",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 50.86396694536552,
			"y": 59.07934673564961,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 90.99993896484375,
			"height": 20,
			"seed": 1559643689,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1672198218161,
			"link": null,
			"fontSize": 16,
			"fontFamily": 1,
			"text": "SBI-service",
			"rawText": "SBI-service",
			"baseline": 13,
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "YKehM6A1Q8Tffb9RX0r-H",
			"originalText": "SBI-service"
		},
		{
			"type": "rectangle",
			"version": 782,
			"versionNonce": 2001841709,
			"isDeleted": false,
			"id": "5NfSovrLFhnBSibdOrvxR",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -138.02783976449746,
			"y": -67.09519040677947,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 114.193115234375,
			"height": 32,
			"seed": 280408429,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "F7qjg9kk",
					"type": "text"
				},
				{
					"id": "r0k0gTOeJLZyt9D4Fa83q",
					"type": "arrow"
				},
				{
					"id": "F7qjg9kk",
					"type": "text"
				},
				{
					"id": "F7qjg9kk",
					"type": "text"
				},
				{
					"id": "y2fd8UdP3H8qTFaO9e9z2",
					"type": "arrow"
				},
				{
					"type": "text",
					"id": "F7qjg9kk"
				}
			],
			"updated": 1672198191072,
			"link": null
		},
		{
			"type": "text",
			"version": 700,
			"versionNonce": 579426083,
			"isDeleted": false,
			"id": "F7qjg9kk",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -133.02783976449746,
			"y": -62.095190406779466,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 104.193115234375,
			"height": 22,
			"seed": 5842915,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1672198191072,
			"link": null,
			"fontSize": 20,
			"fontFamily": 4,
			"text": "建立栈空间",
			"rawText": "建立栈空间",
			"baseline": 19,
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "5NfSovrLFhnBSibdOrvxR",
			"originalText": "建立栈空间"
		},
		{
			"type": "rectangle",
			"version": 810,
			"versionNonce": 649420941,
			"isDeleted": false,
			"id": "A39jwrKY_kvE4vSVw4lvK",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -136.07227335824746,
			"y": -25.23181760404509,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 114.193115234375,
			"height": 32,
			"seed": 1269713827,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "QVp5tson",
					"type": "text"
				},
				{
					"id": "r0k0gTOeJLZyt9D4Fa83q",
					"type": "arrow"
				},
				{
					"id": "QVp5tson",
					"type": "text"
				},
				{
					"id": "QVp5tson",
					"type": "text"
				},
				{
					"id": "y2fd8UdP3H8qTFaO9e9z2",
					"type": "arrow"
				},
				{
					"id": "QVp5tson",
					"type": "text"
				},
				{
					"type": "text",
					"id": "QVp5tson"
				}
			],
			"updated": 1672198191072,
			"link": null
		},
		{
			"type": "text",
			"version": 754,
			"versionNonce": 1379433155,
			"isDeleted": false,
			"id": "QVp5tson",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -131.07227335824746,
			"y": -20.23181760404509,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 104.193115234375,
			"height": 22,
			"seed": 1172829197,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1672198191072,
			"link": null,
			"fontSize": 20,
			"fontFamily": 4,
			"text": "bss段清零",
			"rawText": "bss段清零",
			"baseline": 19,
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "A39jwrKY_kvE4vSVw4lvK",
			"originalText": "bss段清零"
		},
		{
			"type": "rectangle",
			"version": 58,
			"versionNonce": 1739835117,
			"isDeleted": false,
			"id": "BYgF0suRhuCI48dvz2AEc",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "dashed",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -139.48731242074746,
			"y": -83.70456540677947,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 124.44256591796875,
			"height": 107.35360717773438,
			"seed": 2004918915,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1672198191072,
			"link": null
		},
		{
			"type": "text",
			"version": 247,
			"versionNonce": 1937910371,
			"isDeleted": false,
			"id": "C9Xp75L4",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -132.83802042855996,
			"y": -130.14285886381072,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 111,
			"height": 44,
			"seed": 1134943779,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "y2fd8UdP3H8qTFaO9e9z2",
					"type": "arrow"
				}
			],
			"updated": 1672198191072,
			"link": null,
			"fontSize": 20,
			"fontFamily": 4,
			"text": "APP运行前的\n初始化工作",
			"rawText": "APP运行前的\n初始化工作",
			"baseline": 40,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "APP运行前的\n初始化工作"
		},
		{
			"type": "rectangle",
			"version": 943,
			"versionNonce": 1001419885,
			"isDeleted": false,
			"id": "SodweLyClZZNLiTK8N-Sk",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 15.913627520658792,
			"y": -119.02033078763884,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 130.4056396484375,
			"height": 32,
			"seed": 768904643,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "0koKzjAw",
					"type": "text"
				},
				{
					"id": "r0k0gTOeJLZyt9D4Fa83q",
					"type": "arrow"
				},
				{
					"id": "0koKzjAw",
					"type": "text"
				},
				{
					"id": "0koKzjAw",
					"type": "text"
				},
				{
					"id": "y2fd8UdP3H8qTFaO9e9z2",
					"type": "arrow"
				},
				{
					"id": "0koKzjAw",
					"type": "text"
				},
				{
					"type": "text",
					"id": "0koKzjAw"
				}
			],
			"updated": 1672198193445,
			"link": null
		},
		{
			"type": "text",
			"version": 875,
			"versionNonce": 1829836003,
			"isDeleted": false,
			"id": "0koKzjAw",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 20.913627520658792,
			"y": -114.02033078763884,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 120.4056396484375,
			"height": 22,
			"seed": 836133869,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1672198193445,
			"link": null,
			"fontSize": 20,
			"fontFamily": 4,
			"text": "输出字符串",
			"rawText": "输出字符串",
			"baseline": 19,
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "SodweLyClZZNLiTK8N-Sk",
			"originalText": "输出字符串"
		},
		{
			"type": "rectangle",
			"version": 1006,
			"versionNonce": 918506541,
			"isDeleted": false,
			"id": "mRW3HV18Yn6I5Q9DEvOhm",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 15.935478106596292,
			"y": -79.25131833646697,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 132.5965576171875,
			"height": 32,
			"seed": 427634179,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "D2cvnKGq",
					"type": "text"
				},
				{
					"id": "r0k0gTOeJLZyt9D4Fa83q",
					"type": "arrow"
				},
				{
					"id": "D2cvnKGq",
					"type": "text"
				},
				{
					"id": "D2cvnKGq",
					"type": "text"
				},
				{
					"id": "y2fd8UdP3H8qTFaO9e9z2",
					"type": "arrow"
				},
				{
					"id": "D2cvnKGq",
					"type": "text"
				},
				{
					"id": "D2cvnKGq",
					"type": "text"
				},
				{
					"type": "text",
					"id": "D2cvnKGq"
				}
			],
			"updated": 1672198199045,
			"link": null
		},
		{
			"type": "text",
			"version": 921,
			"versionNonce": 281844003,
			"isDeleted": false,
			"id": "D2cvnKGq",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 20.935478106596292,
			"y": -74.25131833646697,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 122.5965576171875,
			"height": 22,
			"seed": 716629933,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1672198199045,
			"link": null,
			"fontSize": 20,
			"fontFamily": 4,
			"text": "关机shutdown",
			"rawText": "关机shutdown",
			"baseline": 19,
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "mRW3HV18Yn6I5Q9DEvOhm",
			"originalText": "关机shutdown"
		},
		{
			"type": "text",
			"version": 424,
			"versionNonce": 1371419149,
			"isDeleted": false,
			"id": "TtcTgT0o",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 39.13103474722129,
			"y": -156.11148679349822,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 93,
			"height": 22,
			"seed": 509846893,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "y2fd8UdP3H8qTFaO9e9z2",
					"type": "arrow"
				}
			],
			"updated": 1672198191073,
			"link": null,
			"fontSize": 20,
			"fontFamily": 4,
			"text": "OS Service",
			"rawText": "OS Service",
			"baseline": 19,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "OS Service"
		},
		{
			"type": "line",
			"version": 389,
			"versionNonce": 1442808131,
			"isDeleted": false,
			"id": "_WDUNqzSFIRScjIfOl5N7",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "dashed",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -206.8451776116259,
			"y": -28.22328527625905,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 51.056762166321164,
			"height": 41.0059655383229,
			"seed": 38653741,
			"groupIds": [],
			"strokeSharpness": "round",
			"boundElements": [],
			"updated": 1672198191073,
			"link": null,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					51.056762166321164,
					-41.0059655383229
				]
			]
		},
		{
			"type": "rectangle",
			"version": 1032,
			"versionNonce": 917518605,
			"isDeleted": false,
			"id": "9aiqe7_jjYffeBAfxaZYT",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 18.000992192507283,
			"y": -42.366308570841966,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 133,
			"height": 32,
			"seed": 582958733,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [
				{
					"id": "C1egQfdG",
					"type": "text"
				},
				{
					"id": "r0k0gTOeJLZyt9D4Fa83q",
					"type": "arrow"
				},
				{
					"id": "C1egQfdG",
					"type": "text"
				},
				{
					"id": "C1egQfdG",
					"type": "text"
				},
				{
					"id": "y2fd8UdP3H8qTFaO9e9z2",
					"type": "arrow"
				},
				{
					"id": "C1egQfdG",
					"type": "text"
				},
				{
					"id": "C1egQfdG",
					"type": "text"
				},
				{
					"id": "C1egQfdG",
					"type": "text"
				},
				{
					"type": "text",
					"id": "C1egQfdG"
				}
			],
			"updated": 1672198202784,
			"link": null
		},
		{
			"type": "text",
			"version": 958,
			"versionNonce": 156212227,
			"isDeleted": false,
			"id": "C1egQfdG",
			"fillStyle": "hachure",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 23.000992192507283,
			"y": -37.366308570841966,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 123,
			"height": 22,
			"seed": 1522760899,
			"groupIds": [],
			"strokeSharpness": "sharp",
			"boundElements": [],
			"updated": 1672198206230,
			"link": null,
			"fontSize": 20,
			"fontFamily": 4,
			"text": "panic处理",
			"rawText": "panic处理",
			"baseline": 19,
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "9aiqe7_jjYffeBAfxaZYT",
			"originalText": "panic处理"
		}
	],
	"appState": {
		"theme": "light",
		"viewBackgroundColor": "#ffffff",
		"currentItemStrokeColor": "#000000",
		"currentItemBackgroundColor": "transparent",
		"currentItemFillStyle": "hachure",
		"currentItemStrokeWidth": 0.5,
		"currentItemStrokeStyle": "dashed",
		"currentItemRoughness": 1,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 4,
		"currentItemFontSize": 16,
		"currentItemTextAlign": "left",
		"currentItemStrokeSharpness": "sharp",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "arrow",
		"currentItemLinearStrokeSharpness": "round",
		"gridSize": null
	},
	"files": {}
}
```
%%